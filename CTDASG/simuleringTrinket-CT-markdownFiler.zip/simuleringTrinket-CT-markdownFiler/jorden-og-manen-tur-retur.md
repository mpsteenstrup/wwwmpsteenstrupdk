** Jorden og Månen **

Vi har nu værktøjet til at simulere satellitter og derfor vores største satellit, Månen.

Nedenfor er en simulering med Jorden og Månen, ca. 400.000 km.

<iframe src='https://trinket.io/embed/glowscript/4011aa171b?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

** Øvelser **
* Kør simuleringen og prøv at lav I størrelsen af Jorden og Månen, så de kan ses. Vær opmærksom på at det ikke er den rigtige størrelse I så har.


** Rejsen til Månen **

Apollo 8 missionen sendte den 21. december 1968 tre astronauter en tur rundt om Månen.
Flyveplanen kan ses her.
![Apollo 8 Orbital Plan.jpg](/api/files/5c3c667221bcdefe4fe111c4/apollo-8-orbital-plan.jpeg "Apollo 8 Orbital Plan.jpg")

Det er jeres opgave at eftergøre denne mission. I skal bruge hvad I har lært tidligere og lave om i koden.

<iframe src='https://trinket.io/embed/glowscript/f06336fbb6?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

** overvejelser **

Hvis I får brug for at lade kameraet følge satellitten så udkommenter linje 26.
* Prøv først at indstil affyringen fra orbit omkring Jorden, så i kommer hent til Månen. 
* Hvad er jeres hastighed når i kommer forbi Månen?
* Den er helt sikkert for høj, prøv at brems fartøjet.
* Prøv at se om I kan gå I orbit om Månen, det er ikke så let.
* Plot den kinetiske, potentielle og mekaniske energi og forklar hvad I ser.
* Det er svært at komme i kredsløb omkring månen, prøv evt. at forøg månens masse og se om det bliver lettere.
* Prøv at gøre simuleringen mere realistisk, indfør eks. bevægelse af månen, lad rumfartøjet accelerer over længere tid med en mindre acceleration, eller hvad I nu har lyst til.



