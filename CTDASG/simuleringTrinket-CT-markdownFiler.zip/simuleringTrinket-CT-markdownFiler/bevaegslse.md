** Bevæglse **

hvis vi skal have noget til at bevæge sig skal vi bruge et loop. Loops er enormt smarte.

nedenunder er lavet en pil ved brug af arrow kommandoen. For at få den til at bevæge sig skal vi opdatere positionen. x positionen af pilen skrives som pil.pos.x ( pilens x position).

loopet starter med at vi sætter i=0 for at have en start. De tre indrykkede linjer bliver kørt igen og igen så længe betingelsen (i<20) er opfyldt. Derfor er det vigtigt med tredje linje hvor i=i+1. Det giver ikke matematisk mening men betyder at vi lægger 1 til i.
```
i=0
while i<20:
  rate(10)
  pil.pos.x = i
  i = i+1
```
prøv at kør programmet og se hvad det gør.

<iframe src='https://trinket.io/embed/glowscript/e5f472cc06?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

* Beskriv hvad der sker med pilen.
* Lav om på rate.
* Skriv pil.pos.x = i + pil.pos.x, hvad sker der?
* Udkommenter de fire linjer med rotation.
* Prøv at beskriv hvad den nye del af koden gør.
* Fri leg, lav andre figure og få dem til at flytte sig.