**Jorden og en satellit, simpelt setup**

For at komme i gang vil vi se på Jorden og få en satellit til at foretage cirkelbevægelser omkring joren.

VPython har elementer som sphere og arrows, som bliver skrevet som vektorer. Det er meget brugbart for os, da bevægelse og krafter også kan beskrives med vektorer.
Kraften, kan skrives som 
$$
\vec{F} = (F_x,F_y,F_z)
$$
Vi kan bruge Newtons 2 lov til at finde accelerationen, hvis vi kender massen,m
$$
\vec{a} = \frac{\vec{F}}{m}.
$$
Den eneste kraft er tyngdekraften og den kan skrives som,
$$
\vec{F} = -G\frac{mM}{r^3}\vec{r},
$$
hvor, *G* er gravitationskonstanten, *m* satellittens masse, *M* jordens masse og *r* afstanden mellem jordens centrum og satellitten.

** Affyring fra jorden **

Jo længere vi er væk fra Jorden jo lavere er tyngdekraften. I loopet beregnes tyngdekraften med. 
```
 F=-G*mSat*mEarth/(mag(r)**3)*r

```
hvor 
```
mag()
```
giver størrelsen, eller længden af vektoren.

Prøv at kør programmet.
<iframe src='https://trinket.io/embed/glowscript/84d5c14922?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

**Øvelse**

* Tjek om den mekaniske energi er bevaret, og fortolk den graferne for den kinetiske og potentielle.
* Prøv at skift affyringsretning til vandret, v.sat=vec(0,v,0).
* Undersøg hvilken starthastighed der skal til for at lave et helt omløb.
* Prøv at fortolk Ekin og Epot, ja og Emek.


** affyring til kredsløb **

Ovenfor fik vi en sattellit i kredsløb ved at sende den vandret afsted. Det resulterede i en bane hvor sattelitten kom tilbage til afsenderen, altså tilbage til Jorden. Hvis vi vil have et rigtigt kredsløb bliver vi nød til at give vores sattellit endnu et skub. 

Det gøres ved
```
if (t>(60*60) and a==0):
    F = F + push*norm(sat.v)
    arrow(pos=sat.pos, axis=norm(sat.v)*1e7)
    a=1
```
inde i while loopet. Koden aktiveres når tiden er større end (60*60) sekunder og a==0 gør at det kun sker én gang. Kraften bliver opdateret med et skub, push, i sattelittens bevægelsesretning, norm(sat.v).

<iframe src='https://trinket.io/embed/glowscript/614793edc7?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>


** øvelse **
* Prøv at lav den mest ciruklære orbit som muligt, ved at ændre på, størrelsen af skubbet, push, og tidspunktet for skubbet ( hint overvej hvornår satellitten er længst fra Jorden).
* Undersøg sattelittens hastighed ved at plotte grafen for (t,mag(sat.v))
* Undersøg hvad der sker hvis skubbet ikke er i sattelittens bevægelsesretning.


** satellit i kredsløb **

I simulationen nedenfor starten vores satellit i højden, d, med en hastighed, v, vinkelret på Jorden.


<iframe src='https://trinket.io/embed/glowscript/a0d82452ba?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>


**Øvelse**
* Besktiv om det visuelt ser ud til at satellittens fart er konstant.
* Hvad er forskellen på hastighed og fart.

For at komme videre skal I ændre i koden

**Øvelser**

Vektoren (0,v,0) i linje 27 definerer starthastigheden 
* Prøv at ændre i starthastigheden, eks. 80% eller 120%.
* Prøv også at ændre vinklen ved at give en hastighed langs de andre akser

**Øvelse**

Der er flere parametre I kan ændre på, og det skal I.
* Find det sted i koden hvor Jordens masse bliver defineret, Me, og forøg den. Hvad sker der med omløbstiden.
* Gør det samme med satellittens masse. Hvad sker der så.
* Prøv også at ændre på afstanden, hvordan tror I at omløbstiden afhænger af afstanden.


**Øvelse**

Jorden bliver i linje 21 roteret en kvart omgang, $\(\pi /2\)$, omkring x aksen.
* Kopier linje 21 ned i loopet, husk indryk og sæt $\(angle=pi/1000\)$.
* Ret den akse jorden roterer om så det ikke er så fjollet.

Tiden i loopet er $\( 60\cdot 60\cdot 12 \)$, altså 12 timer
* skift det til 24 timer og afpas Jordens rotation så den foretager netop én rotation på 24 timer.

** Konklusion, eller metarefleksion **

Overvej hvor du har brugt de fire elementer af Computational Thinking 
* Decomposition
* Abstraction
* Pattern recognition
* Algorithms