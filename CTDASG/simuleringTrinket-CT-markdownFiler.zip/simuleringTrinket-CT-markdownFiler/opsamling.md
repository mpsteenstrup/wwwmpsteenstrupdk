** opsamling programmering **

I har været igennem nogle centrale elementer i programmering her kommer en opsummering.

** løkker **
Løkker eller loops, er dele af programmet som gentages. I python sker det ved indryk, i andre programmet eks. vec {}.


<iframe src='https://trinket.io/embed/glowscript/d41f3d648c?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

* eksperimenter, prøv eks. at lave et gitter
* prøv at få noget til at bevæge sig, eks. pil.pos.x=pil.pos.x+1 i en løkke



** hvis betingelser **
De er også kaldet if statements. If statements tjekker en betingelse og udfører det indrykkede hvis betingelsen er opfyldt.


<iframe src='https://trinket.io/embed/glowscript/c86382d20b?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>

** Break **

Vi kan også få noget til at køre uendeligt, eller indtil en betingelse er opfyldt. Det sker med if True og break.

<iframe src='https://trinket.io/embed/glowscript/1b243dfd96?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>


** Lister **

Lister kaldes også arrays og skrives med [] omkring. Man kan putte alt muligt ind i listerne.


<iframe src='https://trinket.io/embed/glowscript/9a30cef7a0?start=result' width='100%' height='400' frameborder='0' marginwidth='0' marginheight='0' allowfullscreen></iframe>








** opsummering fysik **
Formålet med fysikken var at træne jeres forståelse af Potentiel og Kinetisk energi i forbindelse med orbitaler, planeter, satellitter osv.

I skulle gerne kunne svare på følgende.
* Hvordan ser kurverne for Ekin og Epot ud for en satellit i orbit.
* Hvordan afhænger den potentielle energi af afstanden til Jorden.
* Hvordan kommer man fra en kraft til en acceleration.
* Hvordan kommer man fra en acceleration til en ændring i hastigheden.
* Hvordan kommer man fra en hastighed til en ændring i positionen.






