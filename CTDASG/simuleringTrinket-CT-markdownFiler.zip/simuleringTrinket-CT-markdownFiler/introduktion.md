**INTRODUKTION**

Fysikkens love indeholder ofte krafter og acceleration og kan derfor beskrives som 2. ordens differentialligninger. Disse er ofte svære eller umulige at løse analytisk, d.v.s. finde ligningen, men den kan ofte klares numerisk. I denne introduktion prøver vi at arbejde os frem til at kunne gøre det.

**FORDELE**

* Vi kan løse problemer som ikke er analytisk løsbare.
* Vi kan visualisere løsningen, grafer, simulationer.
* Eleverne kan ret let ændre i kode som allerede er lavet.

** SETUP **
Vi bruger online siden trinket.io. Her kan man dele med elever og eleverne kan selv gemme og lave egne programmer.

